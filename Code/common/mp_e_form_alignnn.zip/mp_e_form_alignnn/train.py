from alignn.train_props import train_prop_model 
train_prop_model(batch_size=64,name="alignn",dataset="megnet",prop="e_form")
